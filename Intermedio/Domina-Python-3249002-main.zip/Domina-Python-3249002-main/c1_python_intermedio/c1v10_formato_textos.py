numero = 1

texto_f_string = f"Formato del número {numero}"
print(texto_f_string)

texto_format = "Formato del número {}".format(numero)
print(texto_format)

texto_multilinea = "Línea 1 \nLínea 2"
print(texto_multilinea)

texto_comillas = "Ana dijo \"Buenos días\""
print(texto_comillas)

texto_tabular = "Nombre\tApellido\nAna\tPinto"
print(texto_tabular)
