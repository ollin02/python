lista_append = [1, 2, 3]
lista_extend = [4, 5, 6]
lista_insert = [7, 8, 9]

lista_letras = ["a", "b", "c"]

# Append
lista_append.append(lista_letras)
print(lista_append)

# Extend
lista_extend.extend(lista_letras)
print(lista_extend)

# Insert
lista_insert.insert(1, lista_letras)
print(lista_insert)
