echo "Impresión en consola desde el bash"
