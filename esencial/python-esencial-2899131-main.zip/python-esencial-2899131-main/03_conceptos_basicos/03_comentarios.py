# Mi primer comentario
print("Hello world!")

print("Hello world!") # Mi primer comentario

# print("Hello world!")

# Este es un
# comentario multilínea


"""Este es un
comentario multilínea"""
