nombre = "Ana"

edad = 20

estatura = 1.60

positivo = True
negativo = False

print(type(nombre))
print(type(edad))
print(type(estatura))
print(type(positivo))
