def area_circulo(radio):
    return 3.14 * radio * radio


def perimetro_circulo(radio):
    return  2 * 3.14 * radio
