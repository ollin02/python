def area_cuadrado(lado):
    return lado * lado


def perimetro_cuadrado(lado):
    return lado * 4
