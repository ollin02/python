
def perimetro_cuadrado(lado, unidades):
    perimetro = lado * 4
    print(f"El perimetro es {perimetro} {unidades}")


perimetro_cuadrado(25, "metros")
perimetro_cuadrado(lado=25, unidades="metros")
