APELLIDO = "Pinto"


def funcion():
    print("Mi primera función")
    nombre = "Ana"
    print(f"Mi nombre es {nombre} {APELLIDO}")


funcion()
#print(nombre)
#print(APELLIDO)
