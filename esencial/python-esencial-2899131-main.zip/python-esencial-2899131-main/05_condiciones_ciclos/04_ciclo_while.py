# Ciclo while 
i = 1
while 1 <= 5:
    print(i)
    i += 1


# Uso de la instrucción break
i = 1
while 1 <= 5:
    if i == 3:
        break
    print(i)
    i += 1


# Uso de la instrucción continue
i = 1
while 1 <= 5:
    if i == 3:
        continue
    print(i)
    i += 1
