class Persona:
    def __init__(self):
        print("Constructor")


paco = Persona()
