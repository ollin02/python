class Persona:
    pass


pedro = Persona()
print(type(pedro))

paco = Persona()
print(type(paco))

print(pedro == paco)
