# Error: sintaxis
print "Hola"

# Error: Variable indefinida
print(variable)

# Error: división por cero
print(1/0)

# Error: tipo de dato
print("Hola" + 2)
