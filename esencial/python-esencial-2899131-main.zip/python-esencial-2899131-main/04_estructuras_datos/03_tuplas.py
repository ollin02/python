# Declarar una tupla
lenguajes = ("python", "java", "javascript", "golang")

lenguajes = "python", "java", "javascript", "golang"
print(lenguajes)

# Extraer elementos usando índices
print(lenguajes[0])
print(lenguajes[-1])
