import logging

logger = logging.getLogger(__name__)
print(logger)

logger.warning("Log de advertencia")