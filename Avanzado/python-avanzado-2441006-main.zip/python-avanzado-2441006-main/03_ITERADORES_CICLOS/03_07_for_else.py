lista_nombres = ["Paco", "Emilio", "Javier", "Ana"]

for nombre in lista_nombres:
    print(nombre)
    if nombre == "Javier":
        break
else:
    print("Ciclo terminado")
