"""
range(inicio, fin, paso)
"""
serie_1 = range(5)
print(list(serie_1))

serie_2 = range(5,10)
print(list(serie_2))

serie_3 = range(3,10,2)
print(list(serie_3))

for elemento in serie_3:
    print(elemento)
