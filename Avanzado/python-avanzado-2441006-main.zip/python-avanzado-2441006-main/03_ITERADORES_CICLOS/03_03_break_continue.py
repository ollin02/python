nombres = ["Paco", "Emilio", "Javier"]

for elemento in nombres:
    continue
    print(elemento)
