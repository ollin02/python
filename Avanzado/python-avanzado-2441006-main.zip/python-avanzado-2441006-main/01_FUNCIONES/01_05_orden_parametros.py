def parametros_ordenados(nombre, apellido, *args, **kwargs):
    pass

def parametros_desordenados(nombre, apellido, **kwargs, *args):
    pass