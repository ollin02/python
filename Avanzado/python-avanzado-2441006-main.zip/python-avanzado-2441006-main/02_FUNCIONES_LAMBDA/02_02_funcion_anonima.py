"""Desde el shell de Python

lambda num: num * 2
_(2,)

(lambda num: num * 2)(2)

multiplicacion = lambda num: num * 2
multiplicacion(2)

"""